//package utilities;
//
//import models.Transaction;
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.List;
//
//public class CSVGenerator {
//
////    // Method to create CSV file from transactions
////    public File createCSV(List<Transaction> transactions) {
////        File file = new File("transactions_export.csv");
////        
////        try (FileWriter writer = new FileWriter(file)) {
////            // Write header
////            writer.append("Transaction ID, Amount, Description, Category ID, Date\n");
////            
////            // Write each transaction data
////            for (Transaction transaction : transactions) {
////                writer.append(transaction.getTransactionId())
////                        .append(", ")
////                        .append(String.valueOf(transaction.getAmount()))
////                        .append(", ")
////                        .append(transaction.getDescription())
////                        .append(", ")
////                        .append(String.valueOf(transaction.getCategoryId()))
////                        .append(", ")
////                        .append(transaction.getDate().toString())
////                        .append("\n");
////            }
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
////
////        return file;
////    }
//	
//	public File createCSV(List<Transaction> transactions) {
//	    File file = new File("transactions_export.csv");
//
//	    try (FileWriter writer = new FileWriter(file)) {
//	        // Write header
//	        writer.append("Transaction ID, Amount, Description, Category ID, Date\n");
//
//	        // Write each transaction data
//	        for (Transaction transaction : transactions) {
//	            // Ensure that all values are converted to String using String.valueOf()
//	            writer.append(String.valueOf(transaction.getTransactionId()))  // Convert int to String
//	                    .append(", ")
//	                    .append(String.valueOf(transaction.getAmount()))        // Convert double to String
//	                    .append(", ")
//	                    .append(transaction.getDescription() != null ? transaction.getDescription() : "") // Handle null description
//	                    .append(", ")
//	                    .append(String.valueOf(transaction.getCategoryId()))    // Convert int to String
//	                    .append(", ")
//	                    .append(transaction.getDate() != null ? transaction.getDate().toString() : "") // Handle null date
//	                    .append("\n");
//	        }
//	    } catch (IOException e) {
//	        e.printStackTrace();
//	    }
//
//	    return file;
//	}
//
//}


package utilities;

import models.Transaction;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CSVGenerator {

    // Method to create CSV file from transactions
    public File createCSV(List<Transaction> transactions) {
        File file = new File("transactions_export.csv");

        try (FileWriter writer = new FileWriter(file)) {
            // Write header
            writer.append("Transaction ID, Amount, Description, Category ID, Date\n");

            // Write each transaction data
            for (Transaction transaction : transactions) {
                // Ensure that all values are converted to String using String.valueOf()
                writer.append(String.valueOf(transaction.getTransactionId()))  // Convert int to String
                        .append(", ")
                        .append(String.valueOf(transaction.getAmount()))        // Convert double to String
                        .append(", ")
                        .append(transaction.getDescription() != null ? transaction.getDescription() : "") // Handle null description
                        .append(", ")
                        .append(String.valueOf(transaction.getCategoryId()))    // Convert int to String
                        .append(", ")
                        .append(transaction.getDate() != null ? transaction.getDate().toString() : "") // Handle null date
                        .append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return file;
    }
}

