//package controllers;
//import models.Budget;
//import services.BudgetService;
//public class BudgetController
//{
//	public void setBudget(Double amount, String category) {
//	    // Function logic here
//	}
//
//	public void promptCreateOrUpdate() {
//	    // Function logic here
//	}
//
//	public String select(String option) {
//	    // Function logic here
//	    return ""; // Placeholder return value
//	}
//
//}


package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import models.Budget;
import models.Category;
import services.BudgetService;
import services.CategoryService;
import application.Main;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import application.Main;
import utilities.AlertUtils;
import database.CategoryDAO;
import database.DatabaseConnection;
//
//public class BudgetController {
//
//    @FXML
//    private TextField amountField;  // Bind the TextField from FXML
//    @FXML
//    private ComboBox<String> categoryComboBox;    // Bind ComboBox for category selection
//    @FXML
//    private TextArea descriptionArea; // Bind the TextArea from FXML
//
//    private BudgetService budgetService;
//    private CategoryService categoryService;
// // Constructor for the BudgetController
//    public BudgetController() {
//        // Get a database connection
//        Connection connection = DatabaseConnection.getConnection();
//        
//        // Initialize BudgetService with the connection
//     // Initialize services
//        CategoryDAO categoryDAO = new CategoryDAO();  // Creating CategoryDAO
//        this.categoryService = new CategoryService(categoryDAO); // Injecting CategoryDAO into CategoryService
//       // this.categoryService = new CategoryService(connection);
//        this.budgetService = new BudgetService(connection);
//    }
//    
//    @FXML
//    public void initialize() {
//        try {
//            // Get all categories from the CategoryService
//            List<Category> categories = categoryService.getAllCategories();
//            
//            // Populate the ComboBox with categories
//            categoryComboBox.getItems().setAll(categories); // This now works since ComboBox is of type Category
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    @FXML
//    public void setHandleBudget() {
//        try {
//            // Extract data from the form fields
//            String amountText = amountField.getText();
//            String category = categoryComboBox.getValue();  // Get the selected category from ComboBox
//            String description = descriptionArea.getText();
//
//            // Validate input fields
//            if (amountText.isEmpty() || category == null || category.isEmpty() || description.isEmpty()) {
//                System.out.println("All fields must be filled!");
//                return;
//            }
//
//            // Convert amount to Double
//            Double amount = Double.parseDouble(amountText);
//
//            // Create a Budget object
//            Budget budget = new Budget(amount, category, description,0,0);
//
//            // Call the BudgetService to create or update the budget
//            
//          //  (Double amount, String category, String description, int sum, int alert)
//            
//            boolean isCreated = budgetService.createBudget(budget);
//
//            // Provide feedback to the user
//            if (isCreated) {
//                System.out.println("Budget created successfully.");
//            } else {
//                System.out.println("Error creating the budget.");
//            }
//        } catch (Exception ex) {
//            System.out.println("Error: " + ex.getMessage());
//        }
//    }
//}

public class BudgetController {

	public AlertUtils popup;
    @FXML
    private TextField amountField;  // Bind the TextField from FXML
    @FXML
    private ComboBox<String> categoryComboBox;    // Bind ComboBox for category selection
    @FXML
    private TextArea descriptionArea; // Bind the TextArea from FXML
    @FXML
    private Button backButton;

    private BudgetService budgetService;
    private CategoryService categoryService;
    public Main m; 
    // Constructor for the BudgetController
    public BudgetController() {
        // Get a database connection
        Connection connection = DatabaseConnection.getConnection();

        // Initialize services
        CategoryDAO categoryDAO = new CategoryDAO();  // Creating CategoryDAO
        this.categoryService = new CategoryService(categoryDAO); // Injecting CategoryDAO into CategoryService
        this.budgetService = new BudgetService(connection);
    }

    @FXML
    public void goBackToHome() {
       
        	m.switchScene("Home", "/views/Home2.fxml");
           
    }

    @FXML
    public void initialize() {
        try {
            // Get all categories from the CategoryService
            List<Category> categories = categoryService.getAllCategories();
            
            // Convert Category objects to String (category names)
            List<String> categoryNames = new ArrayList<>();
            for (Category category : categories) {
                categoryNames.add(category.toString()); // Assuming toString() returns category name
            }
            
            // Populate the ComboBox with category names
            categoryComboBox.getItems().setAll(categoryNames);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void setHandleBudget() {
        try {
            // Extract data from the form fields
            String amountText = amountField.getText();
            String category = categoryComboBox.getValue();  // Get the selected category from ComboBox
            String description = descriptionArea.getText();

            // Validate input fields
            if (amountText.isEmpty() || category == null || category.isEmpty() || description.isEmpty()) {
                System.out.println("All fields must be filled!");
                return;
            }

            // Convert amount to Double
            Double amount = Double.parseDouble(amountText);

            // Create a Budget object
            Budget budget = new Budget(amount, category, description, 0, 0);

            // Call the BudgetService to create or update the budget
            boolean isCreated = budgetService.createBudget(budget);

            // Provide feedback to the user
            if (isCreated) {
                System.out.println("Budget created successfully.");
                popup.showSuccess("Budget created successfully.");
            } else {
                System.out.println("Error creating the budget.");
                popup.showWarning("Error creating the budget.");
            }
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
}

