package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import services.ReminderService;
import models.Reminder;
import java.sql.Connection;
import java.util.List;
import database.DatabaseConnection;
import application.Main;

public class ReminderController {

    @FXML
    private TextField paymentDetailsField;
    @FXML
    private DatePicker reminderDatePicker;
    @FXML
    private Button setReminderButton;

    private ReminderService reminderService;
    public Main m; 
    @FXML
    private Button backButton;
    public ReminderController() {
        Connection connection = DatabaseConnection.getConnection();
        this.reminderService = new ReminderService(connection);
    }
    @FXML
    public void goBackToHome() {
       
        	m.switchScene("Home", "/views/Home2.fxml");
           
    }

    // Show reminder pop-up when the form is loaded
    @FXML
    public void initialize() {
        try {
            List<Reminder> dueReminders = reminderService.getRemindersDueToday();
            if (dueReminders.isEmpty()) {
                showNoReminderDueAlert();
            } else {
                showDueRemindersAlert(dueReminders);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Show pop-up if no reminder is due today
    private void showNoReminderDueAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("No Reminders Due");
        alert.setHeaderText("No transaction reminders due today.");
        alert.setContentText("You can add new reminders for upcoming payments.");
        alert.showAndWait();
    }

    // Show pop-up with due reminders for today
    private void showDueRemindersAlert(List<Reminder> dueReminders) {
        StringBuilder content = new StringBuilder();
        for (Reminder reminder : dueReminders) {
            content.append(reminder.getDescription()).append("\n");
        }

        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Reminders Due Today");
        alert.setHeaderText("The following reminders are due today:");
        alert.setContentText(content.toString());
        alert.showAndWait();
    }

    // Handle setting a new reminder
    @FXML
    public void addReminder() {
        try {
            String paymentDetails = paymentDetailsField.getText();
            String description = paymentDetails + " (Reminder)";  // Add any other logic for description
            java.sql.Date reminderDate = java.sql.Date.valueOf(reminderDatePicker.getValue());

            Reminder reminder = new Reminder(reminderDate, description);
            boolean isCreated = reminderService.addReminder(reminder);

            if (isCreated) {
                showSuccessAlert();
            } else {
                showErrorAlert();
            }
        } catch (Exception e) {
            showErrorAlert();
            e.printStackTrace();
        }
    }

    // Show success alert when reminder is added
    private void showSuccessAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Reminder Set");
        alert.setHeaderText("Your reminder has been set successfully.");
        alert.showAndWait();
    }

    // Show error alert when there is an issue with adding a reminder
    private void showErrorAlert() {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("There was an error while setting your reminder.");
        alert.showAndWait();
    }
}
