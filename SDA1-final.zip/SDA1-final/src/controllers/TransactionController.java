

package controllers;
import java.sql.Connection;
import java.sql.SQLException;

import java.text.ParseException;  // Add this import
import java.util.Date;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import services.CategoryService;
import models.Category;
import application.Main;
import services.TransactionService;
import database.CategoryDAO;
import database.DatabaseConnection;
import models.Transaction;
import database.TransactionDAO;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.Button;
import java.io.IOException;
import javafx.scene.Scene;

import javafx.scene.control.Label;
import utilities.AlertUtils;


import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;


public class TransactionController {
    @FXML
    private TextField transactionIdField;  // Bind the TextField from FXML
    @FXML
    private TextField categoryField;       // Bind the TextField from FXML
    @FXML
    private TextArea transactionDetailsArea;  // Bind the TextArea from FXML
    
    @FXML
    private TextArea transactionAmount;  // Bind the TextArea from FXML
    
    @FXML
    private ComboBox<Category> categoryComboBox;  // The ComboBox to select category
    @FXML
    private TextArea reportSummary;  // The TextArea to show the generated report summary
    @FXML
    private TextArea sumAmount;  // The TextArea to show the generated report summary

    @FXML
    private Label feedbackLabel;  // Ensure this is properly annotated
  
    ///////////////////////////
    
//    @FXML
//    private TextField typeField;

    @FXML
    private TextField amountField;

    @FXML
    private TextField descriptionField;

    @FXML
    private DatePicker dateField;

    @FXML
    private Button backButton;

//    @FXML
//    private ComboBox<Category> categoryComboBox1;    
    
    ///////////////////////////////
    private CategoryService categoryService;
    private TransactionService transactionService;
    public AlertUtils popup;
    public Main m; 
    
    
    @FXML
    public void goBackToHome() {
       
        	m.switchScene("Home", "/views/Home2.fxml");
           
    }

    // Public no-argument constructor required by JavaFX
    public TransactionController() {
    	
    	Connection connection = DatabaseConnection.getConnection();
    	
    	 // Initialize the CategoryDAO and CategoryService here
        CategoryDAO categoryDAO = new CategoryDAO();  // Creating CategoryDAO
        categoryService = new CategoryService(categoryDAO); // Injecting CategoryDAO into CategoryService

        // Initialize TransactionDAO and inject it into TransactionService
        TransactionDAO transactionDAO = new TransactionDAO();  // Create TransactionDAO
        transactionService = new TransactionService(transactionDAO, connection);  // Inject TransactionDAO into TransactionService
    }
 // Constructor used for explicit injection if needed (for advanced use cases)
    public TransactionController(TransactionService transactionService, CategoryService categoryService) {
        this.transactionService = transactionService;
        this.categoryService = categoryService;
    }
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }
    
    @FXML
    public boolean addTransaction() {
        try {
            // Get user input
          //  String type = typeField.getText().trim();
            double amount = Double.parseDouble(amountField.getText().trim());
            String description = descriptionField.getText().trim();
            Date transactionDate = java.sql.Date.valueOf(dateField.getValue());

            Category selectedCategory = categoryComboBox.getValue();

            if ( description.isEmpty() || selectedCategory == null) {
                return false;  // Validation failed
            }

            // Create a new Transaction object
         //   Transaction(transactionId, type, amount, category, transactionDate, description);
           // Transaction(int transactionId, double amount, Category category, Date date, String notes)
            Transaction transaction = new Transaction(0,amount, selectedCategory,transactionDate,description);

            // Delegate the save action to the service
            return transactionService.addTransaction(transaction);

        } catch (Exception e) {
            e.printStackTrace();
            return false;  // Return false if an exception occurs
        }
    }

    @FXML
    public void categorizeTransaction() throws SQLException {
       // try 
    	{
    	
            // Extract the transaction ID and category name from the form
            String transactionId = transactionIdField.getText();
            String categoryName = categoryField.getText();

            // Call CategoryService to find or create the category
            Category category = categoryService.findOrCreateCategory_CAT(categoryName);
            	
            // Check if the category was successfully found or created
            if (category != null) {
                System.out.println("Category found or created: " + category.getName());
               
                // Now, update the transaction with the new category ID
                boolean transactionUpdated = transactionService.updateTransactionCategory(transactionId, category.getId());

                if (transactionUpdated) {
                    System.out.println("Transaction categorized successfully.");
                    popup.showSuccess("Transaction categorized successfully.");
                } else {
                    System.out.println("Error categorizing transaction.");
                }
            } else {
                System.out.println("Error categorizing transaction: Category not found or created.");
            }
        } 
//    	catch (Exception ex) {
//            System.out.println("Error: " + ex.getMessage());
//        }
    }
    
//    
//    
    

  public boolean addTransaction(String type, double amount, String description, String transactionDateString, Category category) throws SQLException {
      try {
          // Validate the transaction inputs
          if (!transactionService.validateTransaction(type, amount, description, transactionDateString)) {
              return false;
          }
          
          // Create a new transaction from the provided details
          Transaction transaction = transactionService.createTransaction(0, type, amount, category, transactionDateString, description);
          
          // Save the transaction
          return transactionService.addTransaction(transaction);
      } catch (ParseException e) {
          // Handle invalid date format or other exceptions
          return false;
      }
  }

    // Other methods for adding, editing, and deleting transactions...
  
  @FXML
  public void editTransaction() throws SQLException {
    //  try {
          // Extract transaction ID, description, and amount from the form
          int transactionId = Integer.parseInt(transactionIdField.getText());  // Now it's an integer
          String transactionDetails = transactionDetailsArea.getText();
          String transactionAmountText = transactionAmount.getText();
        
         // double transactionAmount = Double.parseDouble(transactionAmountText);
          double transactionAmount = 989.92;  // Default value if the field is empty or invalid
          if (!transactionAmountText.isEmpty()) {
              
                  transactionAmount = Double.parseDouble(transactionAmountText);  // Try parsing the amount
              }
          
          
          // Call TransactionService to update both amount and description in the transaction
          boolean result = transactionService.editTransaction(transactionId, transactionDetails, transactionAmount);

          if (result) {
              System.out.println("Transaction updated successfully.");
              popup.showSuccess("Transaction updated successfully.");
          } else {
              System.out.println("Error updating transaction.");
          }

  }



  // Delete Transaction: Delete a transaction by its ID
  @FXML
  public void deleteTransaction() throws SQLException {
    //  try {
          // Extract the transaction ID from the form
          int transactionId = Integer.parseInt(transactionIdField.getText());  // Now it's an integer

          // Call TransactionService to delete the transaction
          boolean result = transactionService.deleteTransaction(transactionId);

          if (result) {
              System.out.println("Transaction deleted successfully.");
              popup.showSuccess("Transaction deleted successfully.");
          } else {
              System.out.println("Error deleting transaction.");
          }
    
  }
  
  // Method to load the categories into the ComboBox
//  @FXML
//  public void initialize() {
//      try {
//          List<Category> categories = categoryService.getAllCategories();  // Fetch all categories
//          categoryComboBox.getItems().addAll(categories);  // Add categories to the ComboBox
//      } catch (SQLException e) {
//          e.printStackTrace();
//      }
//  }
  
  public void initialize() throws SQLException {
	    // Make sure the ComboBox is initialized before trying to access it
	    if (categoryComboBox != null) {
	        // Populate the ComboBox with categories, for example:
	        categoryComboBox.getItems().setAll(categoryService.getAllCategories());
	    }
	}
  // Method to generate a report based on the selected category
  @FXML
  public void categoryReport() throws SQLException {
     // try {
          // Get the selected category from the ComboBox
          Category selectedCategory = categoryComboBox.getValue();

          if (selectedCategory != null) {
              // Fetch the report summary based on the selected category
              String report = transactionService.generateCategoryReport(selectedCategory);
              double sum= transactionService.findsum(selectedCategory);

              // Display the generated report in the TextArea
              reportSummary.setText(report);
              sumAmount.setText(String.format("%.2f", sum));  // Formats the sum to 2 decimal places
          } else {
              reportSummary.setText("Please select a category.");
          }
//      } catch (SQLException e) {
//          reportSummary.setText("Error generating report: " + e.getMessage());
//          e.printStackTrace();
//      }
  }
}

