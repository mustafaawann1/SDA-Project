//
//
//package controllers;
//
//import services.ReportService;
//import models.Report;
//import javafx.scene.control.TextArea;
//import java.util.Date;
//
//public class ReportController {
//    private ReportService reportService;
//
//    public ReportController(ReportService reportService) {
//        this.reportService = reportService;
//    }
//
//    public void viewTransactionHistory(Date startDate, Date endDate, TextArea reportArea) {
//        try {
//            // Simulate fetching data
//            reportArea.setText("Generating report from " + startDate + " to " + endDate + "...\n");
//
//            // Example: Fetch data and append to the TextArea
//            String reportData = fetchReportDataFromDatabase(startDate, endDate); // Hypothetical method
//            reportArea.appendText(reportData);
//        } catch (Exception e) {
//            reportArea.setText("Error generating report: " + e.getMessage());
//        }
//    }
//    private String fetchReportDataFromDatabase(Date startDate, Date endDate) {
//        // Simulating database data
//        StringBuilder data = new StringBuilder();
//        data.append("Transaction 1: Income - $500 on 2024-11-20\n");
//        data.append("Transaction 2: Expense - $200 on 2024-11-21\n");
//        return data.toString();
//    }
//
//
//}
package controllers;

import services.ReportService;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import java.util.Date;
import models.Report;

import java.sql.*;
import controllers.ReportController;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import models.Report;
import services.ReportService;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import database.DatabaseConnection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import application.Main;
public class ReportController {
    private ReportService reportService;

    // Initialize FXML components
    @FXML
    private DatePicker startDatePicker;  // Ensure fx:id matches in FXML
    @FXML
    private DatePicker endDatePicker;    // Ensure fx:id matches in FXML
    @FXML
    private TextArea reportArea;          // Ensure fx:id matches in FXML
    @FXML
    private Button generateButton; // Ensure fx:id matches in FXML
    public Main m; 
    // Constructor for initializing ReportService
    public ReportController() {
        this.reportService = new ReportService(); // Create or inject ReportService here
    }

    @FXML
    public void goBackToHome() {
       
        	m.switchScene("Home", "/views/Home2.fxml");
           
    }

    // Constructor with ReportService dependency injection
    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    /**
     * Method to handle the "Generate Report" button click in the FXML.
     */
    @FXML
    public void handleGenerateReport() {
        try {
            // Get the dates from the DatePickers in the FXML file
            Date startDate = getDateFromDatePicker(startDatePicker);  // startDatePicker should be bound in FXML
            Date endDate = getDateFromDatePicker(endDatePicker);      // endDatePicker should be bound in FXML

            // Validate input
            if (startDate == null || endDate == null) {
                reportArea.setText("Please select both start and end dates.");
                return;
            }

            if (startDate.after(endDate)) {
                reportArea.setText("Error: Start date must be before end date.");
                return;
            }

            // Call the ReportService to generate the report for the selected date range
            String reportData = reportService.generateTransactionHistory(startDate, endDate);

            // Display the report in the TextArea (or display a message if no data found)
            if (reportData.isEmpty()) {
                reportArea.setText("No transactions found for the selected date range.");
            } else {
                reportArea.setText(reportData);
            }

        } catch (Exception e) {
            reportArea.setText("Error generating report: " + e.getMessage());
        }
    }

    /**
     * Helper method to convert DatePicker value to Date.
     * @param datePicker the DatePicker to extract value from
     * @return a Date object or null if no value is selected
     */
    private Date getDateFromDatePicker(DatePicker datePicker) {
        if (datePicker.getValue() == null) {
            return null;
        }
        try {
            return java.sql.Date.valueOf(datePicker.getValue());
        } catch (Exception e) {
            return null;
        }
    }
    
    public void viewTransactionHistory(Date startDate, Date endDate, TextArea reportArea) {
      try {
          // Simulate fetching data
          reportArea.setText("Generating report from " + startDate + " to " + endDate + "...\n");

          // Example: Fetch data and append to the TextArea
          String reportData = fetchReportDataFromDatabase(startDate, endDate); // Hypothetical method
          reportArea.appendText(reportData);
      } catch (Exception e) {
          reportArea.setText("Error generating report: " + e.getMessage());
      }
  }
    private String fetchReportDataFromDatabase(Date startDate, Date endDate) {
      // Simulating database data
      StringBuilder data = new StringBuilder();
      data.append("Transaction 1: Income - $500 on 2024-11-20\n");
      data.append("Transaction 2: Expense - $200 on 2024-11-21\n");
      return data.toString();
  }
}
