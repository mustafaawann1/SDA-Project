package controllers;

import java.sql.Connection;
import java.sql.SQLException;

import database.BudgetDAO;
import database.DatabaseConnection;
import models.Category;
import services.AlertService;
import services.BudgetService;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import utilities.AlertUtils;
import application.Main;
public class AlertController {

    @FXML
    private ComboBox<String> categoryComboBox;  // ComboBox to select category

    private BudgetDAO budgetDAO;
    private AlertService alertService;
    private BudgetService budgetService;
    public  AlertUtils popup;
    public Main m;

    @FXML
    private Button backButton;
    
    public AlertController() {
        // Initialize DAO and Service layers
    	 Connection connection = DatabaseConnection.getConnection();
    	 this.budgetService = new BudgetService(connection);
        alertService = new AlertService(connection);
    }
    
    @FXML
    public void goBackToHome() {
       
        	m.switchScene("Home", "/views/Home2.fxml");
           
    }

    @FXML
    public void initialize() throws SQLException {
    	categoryComboBox.getItems().setAll(budgetService.getCategoriesFromBudget());
    }

   

    // Method to set the alert condition when the user selects a category
    @FXML
    public void setAlert() {
        try {
            String selectedCategory = categoryComboBox.getValue();
            
            if (selectedCategory == null || selectedCategory.isEmpty()) {
                showAlert("Please select a category first.");
                return;
            }

            // Set the alert for the selected category to 1
            boolean success = alertService.setAlertCondition(selectedCategory);

            if (success) {
                showAlert("Alert condition has been set successfully!");
            } else {
                showAlert("Error setting alert condition. Please try again.");
            }
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    // Helper method to show a simple alert dialog
    private void showAlert(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Alert");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
