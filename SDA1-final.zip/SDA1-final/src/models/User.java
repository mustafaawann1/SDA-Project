package models;


public class User {
	
	private int userId;
	   private double balance;

	public User(int userId, double balance) 
	{
	    this.userId = userId;
	    this.balance = balance;
	}
	public void updateBalance(double amount) {
	    this.balance += amount;
	}
	public double getBalance() {
	    return balance;
	}


	
}