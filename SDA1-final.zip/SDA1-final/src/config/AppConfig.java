package config;
import java.util.Properties;
public class AppConfig
{
	
}