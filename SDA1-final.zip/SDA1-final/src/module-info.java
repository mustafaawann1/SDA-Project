module SDA {
//    requires javafx.controls;
//    requires javafx.fxml;
//	requires java.sql;
//
//    exports application;
//    opens application to javafx.fxml;
//    
//    // Exporting the controllers package to javafx.fxml module
//    exports controllers to javafx.fxml;
//    exports services;
//    exports database;
//    exports models;
//    exports utilities;
////    exports recurring;
//    exports alerts;
//  //  exports exceptions;
//    exports config;
	
	   requires javafx.controls;
	    requires javafx.fxml;
	    requires javafx.base;
	    requires java.sql;
	    requires javafx.graphics;

	    opens controllers to javafx.fxml;  // Add this line to open the controllers package to javafx.fxml
	    exports application;
	    exports controllers;
	    exports models;
	    exports services;
	    exports database;
}
