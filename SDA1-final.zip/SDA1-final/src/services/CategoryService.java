package services;

import models.Category;

import java.sql.SQLException;

import java.util.List;
import database.CategoryDAO;

public class CategoryService {
    private CategoryDAO categoryDAO;

    public CategoryService(CategoryDAO categoryDAO) {
        this.categoryDAO = categoryDAO;
    }

    public Category findCategoryById(int id) throws SQLException {
        return categoryDAO.findCategoryById(id);
    }
  
    public Category findOrCreateCategory_CAT(String name) throws SQLException {
        // First, try to find the category by name
        Category category = categoryDAO.findCategoryByName(name);

        // If the category doesn't exist, create a new one
        if (category == null) {
        	 category = new Category(0, name); // ID is 0, it will be assigned by the database
             boolean success = categoryDAO.saveCategory(category);
       
            return category;
        }

        return category;
    }
    
    public boolean findOrCreateCategory(String name) throws SQLException {
        // First, try to find the category by name
        Category category = categoryDAO.findCategoryByName(name);

        // If the category doesn't exist, create a new one
        if (category == null) {
            category = new Category(0, name); // ID is 0, it will be assigned by the database
            boolean success = categoryDAO.saveCategory(category);
            return success;
        }

        return true; // Category already exists
    }

    public boolean updateCategory(Category category) throws SQLException {
        return categoryDAO.updateCategory(category);
    }
    
    public List<Category> getAllCategories() throws SQLException {
        return categoryDAO.getAllCategories();
    }
}


