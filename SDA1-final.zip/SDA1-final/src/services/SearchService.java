package services;
public class SearchService
{
	public SearchService()
	{
		
	}
}