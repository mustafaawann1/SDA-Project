package services;

import database.ReminderDAO;
import models.Reminder;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ReminderService {
    private ReminderDAO reminderDAO;

    public ReminderService(Connection connection) {
        this.reminderDAO = new ReminderDAO(connection);
    }

    // Get reminders that are due today
    public List<Reminder> getRemindersDueToday() throws SQLException {
        return reminderDAO.getRemindersDueToday();
    }

    // Add a new reminder
    public boolean addReminder(Reminder reminder) throws SQLException {
        return reminderDAO.addReminder(reminder);
    }
}
