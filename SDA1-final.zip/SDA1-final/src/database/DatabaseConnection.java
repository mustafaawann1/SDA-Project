//
//package database;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//
//public class DatabaseConnection {
//    private static final String URL = "jdbc:your_database_url";
//    private static final String USER = "your_username";
//    private static final String PASSWORD = "your_password";
//
//    public static Connection getConnection() throws SQLException {
//        return DriverManager.getConnection(URL, USER, PASSWORD);
//    }
//}

package database;

import java.util.List;
import java.util.ArrayList;
import java.sql.*;
import models.Transaction;
import models.Category;  // Ensure to import Category

public class DatabaseConnection {

    private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=StudentDB;integratedSecurity=true;encrypt=true;trustServerCertificate=true;";

    
    // Replace with your database URL
    private static final String USER = "root"; // Replace with your database user
    private static final String PASSWORD = ""; // Replace with your database password
    private static Connection connection;
    
    // Singleton pattern to ensure only one instance of DatabaseConnection
    private static DatabaseConnection instance;

    // Private constructor to prevent instantiation
    private DatabaseConnection() {
        try {
            connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            if (connection != null) {
                System.out.println("Database connection successful.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error: Unable to establish a database connection.");
        }
    }


    // Singleton getInstance method
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnection.class) {
                if (instance == null) {
                    instance = new DatabaseConnection();
                }
            }
        }
        return instance;
    }

 // Getter for the connection object
    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Attempt to reconnect to the database
                connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
                if (connection != null) {
                    System.out.println("Database connection successful.");
                }
            } catch (SQLException e) {
                System.out.println("Error: Unable to establish a database connection.");
                e.printStackTrace();  // Log the exception for more details
            }
        }
        
        return connection;
    }

    // CRUD Operation: Store a new transaction
    public void storeTransaction(Transaction transaction) {
        String query = "INSERT INTO Transactions (amount, type, category, date) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDouble(1, transaction.getAmount());
            stmt.setString(2, transaction.getType());
            stmt.setString(3, transaction.getCategory().getName());  // Get the category name, not the object
            stmt.setDate(4, new java.sql.Date(transaction.getDate().getTime()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // CRUD Operation: Fetch a transaction by its ID
    public Transaction fetchTransactionById(int transactionId) {
        String query = "SELECT * FROM Transactions WHERE transactionId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, transactionId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Create Category with just ID and name
                Category category = new Category(rs.getInt("category_id"), rs.getString("category_name"));
                return new Transaction(
                    rs.getInt("transactionId"),
                    rs.getString("type"),
                    rs.getDouble("amount"),
                    category,  // Pass Category object with ID and name
                    rs.getDate("date"),
                    rs.getString("notes")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    // CRUD Operation: Update an existing transaction
    public void updateTransaction(Transaction transaction) {
        String query = "UPDATE Transactions SET amount = ?, type = ?, category = ?, date = ?, notes = ? WHERE transactionId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDouble(1, transaction.getAmount());
            stmt.setString(2, transaction.getType());
            stmt.setString(3, transaction.getCategory().getName());  // Get the category name, not the object
            stmt.setDate(4, new java.sql.Date(transaction.getDate().getTime()));
            stmt.setString(5, transaction.getDescription());
            stmt.setInt(6, transaction.getTransactionId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // CRUD Operation: Remove a transaction from the database
    public void removeTransaction(int transactionId) {
        String query = "DELETE FROM Transactions WHERE transactionId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, transactionId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // CRUD Operation: Fetch all transactions (optional)
    public List<Transaction> fetchAllTransactions() {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM Transactions";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
            	Category category = new Category(rs.getInt("category_id"), rs.getString("category_name"));
                transactions.add(new Transaction(
                    rs.getInt("transactionId"),
                    rs.getString("type"),
                    rs.getDouble("amount"),
                    category,  // Pass Category object
                    rs.getDate("date"),
                    rs.getString("notes")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transactions;
    }
}
