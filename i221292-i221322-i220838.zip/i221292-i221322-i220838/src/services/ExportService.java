package services;

import models.Transaction;
import utilities.CSVGenerator;
import java.io.File;
import java.util.List;

public class ExportService {

    private CSVGenerator csvGenerator;

    public ExportService() {
        this.csvGenerator = new CSVGenerator();
    }
 // Method to generate the CSV
    public File generateCSV(List<Transaction> transactions) {
        // Delegate the CSV creation to the CSVGenerator
        return csvGenerator.createCSV(transactions);
    }
}
