//package services;
//import database.RecurringTransactionDAO;
//
//
//import models.RecurringTransaction;
//
//public class RecurringTransactionService {
//	public RecurringTransaction requestDetails() {
//	    // Function logic here
//	    return null; // Placeholder return value
//	}
//
//	public Boolean validateDetails() {
//	    // Function logic here
//	    return false; // Placeholder return value
//	}
//
//	public Boolean scheduleFutureEntries() {
//	    // Function logic here
//	    return false; // Placeholder return value
//	}
//
//}
//package services;
//
//import models.RecurringTransaction;
//import models.Transaction;
//import database.RecurringTransactionDAO;
//import java.sql.SQLException;
//import java.util.Date;
//import java.util.List;
//
//public class RecurringTransactionService {
//
//    private RecurringTransactionDAO recurringTransactionDAO;
//
//    public RecurringTransactionService() {
//        this.recurringTransactionDAO = new RecurringTransactionDAO();
//    }
//
//    public void createRecurringTransaction(RecurringTransaction recurringTransaction) {
//        try {
//            // Set the current date for the recurring transaction
//            recurringTransaction.setTransactionDate(new Date());
//
//            // Save the recurring transaction to the database
//            boolean isSuccess = recurringTransactionDAO.saveRecurringTransaction(recurringTransaction);
//            if (isSuccess) {
//                // Notify user or update the UI with success message
//                System.out.println("Recurring transaction created successfully.");
//            } else {
//                System.out.println("Failed to create recurring transaction.");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public List<Transaction> searchTransactionById(String transactionId) throws SQLException {
//        return recurringTransactionDAO.searchTransactionsByTransactionId(transactionId);
//    }
//}


package services;

import models.Transaction;

import java.sql.SQLException;
import java.util.List;

import database.TransactionDAO;

public class RecurringTransactionService {

    private TransactionDAO transactionDAO;

    public RecurringTransactionService() {
        transactionDAO = new TransactionDAO();  // Initialize DAO
    }

    public Transaction searchTransactionById(String transactionId) throws SQLException {
        return transactionDAO.searchTransactionsByTransactionIdT(transactionId);  // Assume this method returns a list of transactions matching the ID
    }

    public boolean saveRecurringTransaction(Transaction transaction) throws SQLException {
        return transactionDAO.saveTransaction(transaction);  // Save the new recurring transaction in the database
    }
}

