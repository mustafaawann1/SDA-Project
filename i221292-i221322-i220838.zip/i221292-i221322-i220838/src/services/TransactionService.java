
//
//package services;
//
//import database.TransactionDAO;
//import models.Transaction;
//import models.Category;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//
//public class TransactionService {
//    private TransactionDAO transactionDAO;
//
//    public TransactionService(TransactionDAO transactionDAO) {
//        this.transactionDAO = transactionDAO;
//    }
//
//    // Method to validate the input for a new transaction
//    public boolean validateTransaction(String type, double amount, String description, String transactionDateString) throws ParseException {
//        // Validate amount
//        if (amount <= 0) {
//            return false;
//        }
//        // Validate description (should not be empty)
//        if (description == null || description.trim().isEmpty()) {
//            return false;
//        }
//        // Validate date format (dd-MM-yyyy)
//        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
//        sdf.setLenient(false);
//        sdf.parse(transactionDateString); // Will throw exception if date is invalid
//        return true;
//    }
//
//    // Method to create a new transaction object from the provided details
//    public Transaction createTransaction(int transactionId, String type, double amount, Category category, String transactionDateString, String description) throws ParseException {
//        // Parse the transaction date
//        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
//        java.util.Date transactionDate = sdf.parse(transactionDateString);
//        
//        // Create and return a new Transaction object
//        return new Transaction(transactionId, type, amount, category, transactionDate, description);
//    }
//
//    // Add transaction to the database
//    public boolean addTransaction(Transaction transaction) {
//        // Add additional business logic here, if necessary
//        return transactionDAO.saveTransaction(transaction);
//    }
//
//    // Update transaction in the database
//    public boolean updateTransaction(Transaction transaction) {
//        return transactionDAO.updateTransaction(transaction);
//    }
//
//    // Delete transaction from the database
//    public boolean deleteTransaction(int transactionId) {
//        return transactionDAO.deleteTransaction(transactionId);
//    }
//}

package services;
import java.util.List;

import database.BudgetDAO;
import database.TransactionDAO;
import models.Transaction;
import models.Category;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TransactionService {
    private TransactionDAO transactionDAO;
    private BudgetDAO budgetDAO;

    public TransactionService(TransactionDAO transactionDAO,Connection connection) {
        this.transactionDAO = transactionDAO;
        this.budgetDAO = new BudgetDAO(connection);
    }

    // Method to validate the input for a new transaction
    public boolean validateTransaction(String type, double amount, String description, String transactionDateString) {
        // Validate amount
        if (amount <= 0) {
            return false;
        }
        // Validate description (should not be empty)
        if (description == null || description.trim().isEmpty()) {
            return false;
        }
        // Validate date format (dd-MM-yyyy)
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            sdf.setLenient(false);
            sdf.parse(transactionDateString); // Will throw exception if date is invalid
        } catch (ParseException e) {
            return false; // Return false if the date format is invalid
        }
        return true;
    }

    // Method to create a new transaction object from the provided details
    public Transaction createTransaction(int transactionId, String type, double amount, Category category, String transactionDateString, String description) throws ParseException {
        // Parse the transaction date
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        java.util.Date transactionDate = sdf.parse(transactionDateString);
        
        // Create and return a new Transaction object
        return new Transaction(transactionId, type, amount, category, transactionDate, description);
    }

    // Add transaction to the database
    public boolean addTransaction(Transaction transaction) throws SQLException {
        // Check if the category exists in the budget table and the Alert flag is set
        boolean isCategoryValid = budgetDAO.checkCategoryInBudget(transaction.getCategory().toString());

        if (isCategoryValid) {
            // Get the alert flag and the current sum for the category
            boolean isAlertSet = budgetDAO.isAlertSetForCategory(transaction.getCategory().toString());
            double currentSum = budgetDAO.getCurrentSumForCategory(transaction.getCategory().toString());
            double budgetAmount = budgetDAO.getBudgetAmountForCategory(transaction.getCategory().toString()); // Target value

            if (isAlertSet) {
                // Check if adding the new transaction amount would exceed the budget
                if (currentSum + transaction.getAmount() > budgetAmount) {
                    // Show alert to the user
                    displayAlert("Category Limit Exceeded", "The limit for the category " + transaction.getCategory() + " has been exceeded, but the transaction will be added.");
                }
            }
            // Update the sum in the budget table
            budgetDAO.updateBudgetSum(transaction.getCategory().toString(), currentSum + transaction.getAmount());
        }
        
        // Add the transaction to the transaction table
        return transactionDAO.saveTransaction(transaction);
    }
    public void displayAlert(String title, String message) {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
//    public boolean addTransaction(Transaction transaction) throws SQLException {
//        // Add additional business logic here, if necessary
//        return transactionDAO.saveTransaction(transaction);
//    }

    // Update transaction in the database
    public boolean updateTransaction(Transaction transaction) throws SQLException {
        return transactionDAO.updateTransaction(transaction);
    }

   
    public boolean updateTransactionCategory(String transactionId, int categoryId) throws SQLException {
        // This method updates the 'category_id' in the transaction table

        //try 
        {
            // Convert the transaction ID to an integer (assuming it’s a valid integer)
            int txnId = Integer.parseInt(transactionId);

            // Call the TransactionDAO to update the category ID of the transaction
            TransactionDAO transactionDAO = new TransactionDAO();
            boolean result = transactionDAO.updateTransactionCategory(txnId, categoryId);

            return result;
        } 
//        catch (NumberFormatException e) {
//            System.out.println("Invalid transaction ID: " + e.getMessage());
//            return false;
//        } 
//        catch (Exception e) {
//            System.out.println("Error updating transaction category: " + e.getMessage());
//            return false;
//        }
    }
    
   
 // Edit a transaction
    public boolean editTransaction(int transactionId, String details, double am) throws SQLException {
        Transaction transaction = transactionDAO.findTransactionById(transactionId);
        if (transaction != null) {
        	// Check if the details are not empty
            if (!details.isEmpty()) {
                transaction.setDescription(details);  // Set the new details if not empty
            }
           if(am!=989.92)
           {
        	   transaction.setAmount(am);
           }
            
            return transactionDAO.updateTransaction(transaction);
        }
        return false;
    }

 // Delete a transaction
    public boolean deleteTransaction(int transactionId) throws SQLException {
        return transactionDAO.deleteTransaction(transactionId);
    }
    
 // Generate a report based on the selected category
    public String generateCategoryReport(Category category) throws SQLException {
        // Fetch transactions for the selected category
        List<Transaction> transactions = transactionDAO.getTransactionsByCategory(category.getId());

        // Generate report summary (for simplicity, we're just listing the transactions)
        StringBuilder report = new StringBuilder("Report for Category: " + category.getName() + "\n");
        report.append("=======================================\n");

        for (Transaction transaction : transactions) {
            report.append("ID: ").append(transaction.getTransactionId())
                  .append(", Amount: ").append(transaction.getAmount())
                  .append(", Date: ").append(transaction.getDate())
                  .append("\n");
        }

        return report.toString();
    }
    
    public double findsum(Category selectedCategory) throws SQLException
    {
    	double x= TransactionDAO.findSumOnCategory(selectedCategory);
    	return x;
    }
    // Method to fetch all transactions for a specific category
    public List<Transaction> fetchTransactionsByCategory(int categoryId) throws SQLException {
        return transactionDAO.getTransactionsByCategory(categoryId);
    }
    
    public List<Transaction> fetchAllTransactions() throws SQLException {
        // Assuming you have a DAO method that fetches all transactions from the database
        return transactionDAO.getAllTransactions();
    }
    
 // Method to search transactions based on user input
    public List<Transaction> searchTransactions(String criteria, String searchValue) throws SQLException {
        switch (criteria) {
            case "Date":
                return transactionDAO.searchTransactionsByDate(searchValue);
            case "Transaction ID":
                return transactionDAO.searchTransactionsByTransactionId(searchValue);
            case "Description":
                return transactionDAO.searchTransactionsByDescription(searchValue);
            default:
                throw new IllegalArgumentException("Invalid search criteria");
        }
    }
}


