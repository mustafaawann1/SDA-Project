//package services;
//import database.BudgetDAO;
//import models.Budget;
//
//
//public class BudgetService {
//	public Boolean createBudget(Double amount, String category) {
//	    // Function logic here
//	    return false; // Placeholder return value
//	}
//
//	public Boolean updateBudget(Double amount, String category) {
//	    // Function logic here
//	    return false; // Placeholder return value
//	}
//
//	  
//}
//

//package services;
//
//import database.BudgetDAO;
//import models.Budget;
//
//public class BudgetService {
//    private BudgetDAO budgetDAO;
//
//    public BudgetService() {
//        this.budgetDAO = new BudgetDAO(); // Initialize BudgetDAO here
//    }
//
//    /**
//     * Create a new budget based on user input.
//     */
//    public Boolean createBudget(Double amount, String category, String desc) {
//        // Create a new Budget instance and pass to the DAO
//    	Budget budget = new Budget(amount, category, desc);
//        budgetDAO.saveBudget(budget);
//        return true;
//       // return budget.createNewBudget(amount, category, desc);  // Create budget in the model
//    }
//
//    /**
//     * Update an existing budget based on user input.
//     */
////    public Boolean updateBudget(Double amount, String category) {
////        // Update the budget using the Budget model
////        Budget budget = new Budget();
////        return budget.updateExistingBudget(amount, category);  // Update the budget in the model
////    }
//}


package services;

import database.BudgetDAO;
import models.Budget;
import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class BudgetService {
    private BudgetDAO budgetDAO;

    public BudgetService(Connection connection) {
        this.budgetDAO = new BudgetDAO(connection);
    }

    public Boolean createBudget(Budget b) throws SQLException {
      //  Budget budget = new Budget(amount, category, description,sum, alert);
        return budgetDAO.saveBudget(b); // This will save the budget to the database
    }

   public List<String> getCategoriesFromBudget() throws SQLException
   {
	   return budgetDAO.getCategoriesFromBudget();
   }
    
}
