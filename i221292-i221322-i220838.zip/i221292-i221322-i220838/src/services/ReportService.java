//package services;
//
//import models.Report;
//import java.util.Date;
//
//public class ReportService {
//    private Report report;
//
//    public ReportService(Report report) {
//        this.report = report;
//    }
//
//    public String generateTransactionHistory(Date startDate, Date endDate) {
//        // Generate the transaction history by fetching data from the Report model
//        return report.create(startDate, endDate); // Calls the model to get the data
//    }
//}
package services;

import models.Report;

import java.sql.SQLException;
import java.util.Date;

public class ReportService {
    private Report report;

    public ReportService() {
        this.report = new Report(); // Initialize the Report model
    }

    public String generateTransactionHistory(Date startDate, Date endDate) throws SQLException {
        // Generate the transaction history by fetching data from the Report model
        return report.create(startDate, endDate); // Calls the model to get the data
    }
}
