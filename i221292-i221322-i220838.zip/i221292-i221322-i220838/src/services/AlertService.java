package services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import database.BudgetDAO;

public class AlertService {

    private BudgetDAO budgetDAO;

    public AlertService(Connection connection) {
       
        budgetDAO = new BudgetDAO(connection);
    }

    public boolean setAlertCondition(String category) {
        // Set the alert column value to 1 for the selected category in the 'budget' table
        try {
            return budgetDAO.setAlertForCategory(category);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
//    public boolean updateAlertForCategory(String category) throws SQLException 
//    {
//        String updateQuery = "UPDATE budget SET alert = 1 WHERE category = ?";  // Assuming 'alert' is the column name
//
//      //  try (
//        		Connection conn = DriverManager.getConnection(DB_URL);
//             PreparedStatement pstmt = conn.prepareStatement(updateQuery); //) {
//
//            pstmt.setString(1, category);  // Set the selected category value
//            int rowsUpdated = pstmt.executeUpdate();
//            return rowsUpdated > 0;
////        } catch (SQLException e) {
////            e.printStackTrace();
////            throw e;
////        }
//    }
}
