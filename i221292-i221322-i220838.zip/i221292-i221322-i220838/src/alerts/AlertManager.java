package alerts;

import services.AlertService;
import models.AlertCondition;
import java.util.Date;


public class AlertManager {

	
}
