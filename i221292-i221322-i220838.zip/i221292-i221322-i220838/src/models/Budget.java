//package models;
//
//public class Budget {
//	int id, amount, category,period;
//	public Boolean createNewBudget(Double amount, String category) {
//	    // Function logic here
//	    return false; // Placeholder return value
//	}
//
//	public Boolean updateExistingBudget(Double amount, String category) {
//	    // Function logic here
//	    return false; // Placeholder return value
//	}
//
//	  
//}
//package models;
//
//public class Budget {
//    private int id;
//    private Double amount;
//    private String category;
//    private String description;
//
//    /**
//     * Create a new budget.
//     */
//    public Budget(Double am, String cat, String desc)
//    {
//    	this.amount=am;
//    	this.category=cat;
//    	this.description=desc;
//    }
////    public Boolean createNewBudget(Double amount, String category, String desc) {
////        // Logic to create a new budget, e.g., saving it to the database
////        System.out.println("Creating budget: " + amount + " for " + category);
////        return true; // Placeholder
////    }
//
//    /**
//     * Update an existing budget.
//     */
//    public Boolean updateExistingBudget(Double amount, String category) {
//        // Logic to update an existing budget
//        System.out.println("Updating budget: " + amount + " for " + category);
//        return true; // Placeholder
//    }
//}


package models;

public class Budget {
    private int id;
    private double amount;
    private String category;
    private String description;
    private int Sum;
    private int Alert;

    // Constructor
    public Budget(double amount, String category, String description,int S, int A) {
        this.amount = amount;
        this.category = category;
        this.description = description;
        this.Sum=S;
        this.Alert=A;
    }

    // Getter methods
    public double getAmount() {
        return amount;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    public int getId() {
        return id;
    }

    // Setter methods
    public void setId(int id) {
        this.id = id;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
