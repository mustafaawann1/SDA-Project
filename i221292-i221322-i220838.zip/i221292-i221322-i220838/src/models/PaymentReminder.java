package models;
public class PaymentReminder
{
	
}