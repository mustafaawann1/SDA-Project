//package models;
//import java.util.Date;
//public class Transaction {
//   private int id;
//   private double amount;
//   private Date date;
//   private String description;
//   private Category category;  // Assuming Category is another class you've defined
//   public Transaction(int id, double amount, Date date, String description, Category category) {
//       this.id = id;
//       this.amount = amount;
//       this.date = date;
//       this.description = description;
//       this.category = category;
//   }
//   // Getters and setters
//   public int getId() {
//       return id;
//   }
//   public void setId(int id) {
//       this.id = id;
//   }
//   public double getAmount() {
//       return amount;
//   }
//   public void setAmount(double amount) {
//       this.amount = amount;
//   }
//   public Date getDate() {
//       return date;
//   }
//   public void setDate(Date date) {
//       this.date = date;
//   }
//   public String getDescription() {
//       return description;
//   }
//   public void setDescription(String description) {
//       this.description = description;
//   }
//   public Category getCategory() {
//       return category;
//   }
//   public void setCategory(Category cat) {
//       this.category = cat;
//   }
//}


package models;

import database.DatabaseConnection;
import java.util.Date;

public class Transaction {
    private int transactionId;
    private String type;
    private double amount;
    private Category category;
    private Date date;
    private String description;

    // Constructor
    public Transaction(int transactionId, String type, double amount, Category category, Date date, String notes) {
        this.transactionId = transactionId;
        this.type = type;
        this.amount = amount;
        this.category = category;
        this.date = date;
        this.description = notes;
    }
    public Transaction(int transactionId, double amount, Category category, Date date, String notes) {
        this.transactionId = transactionId;
        this.type = "";
        this.amount = amount;
        this.category = category;
        this.date = date;
        this.description = notes;
    }

    // Getters and Setters
    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Category getCategory() {
        return category;
    }
    public int getCategoryId() {
        return category.getId();
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String notes) {
        this.description = notes;
    }

    // Save the transaction to the database
    public boolean save() {
        DatabaseConnection db = DatabaseConnection.getInstance();
        db.storeTransaction(this);
        return true;
    }

    // Override toString() for easy representation
    @Override
    public String toString() {
        return "Transaction[ID=" + transactionId + ", Type=" + type + ", Amount=" + amount + 
               ", Category=" + category + ", Date=" + date + ", Description=" + description + "]";
    }
}
