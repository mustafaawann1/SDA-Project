package models;

public class AlertCondition {
	  
}
