package models;

import java.util.Date;

public class RecurringTransaction {

    private int transactionId;
    private double amount;
    private Category category;
    private Date transactionDate;
    private String description;

    public RecurringTransaction(int transactionId, double amount, Category category, Date transactionDate, String description) {
        this.transactionId = transactionId;
        this.amount = amount;
        this.category = category;
        this.transactionDate = transactionDate;
        this.description = description;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
