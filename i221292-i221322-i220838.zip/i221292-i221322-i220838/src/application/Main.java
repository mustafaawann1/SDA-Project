// U1 FORM
//
//package application;
//
//import javafx.application.Application;
//import javafx.scene.Scene;
//import javafx.scene.control.*;
//import javafx.scene.layout.*;
//import javafx.stage.Stage;
//import models.*;
//import services.*;
//import database.*;
//import controllers.*;
//
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//
//import java.sql.*;
//import java.util.List;
//import java.util.ArrayList;
//
//public class Main extends Application {
//
//    private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=SDA_PROJECT;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
//    private TransactionController transactionController;
//
//    @Override
//    public void start(Stage primaryStage) {
//        try {
//            BorderPane root = new BorderPane();
//
//            // Initialize the transaction service
//            TransactionDAO transactionDAO = new TransactionDAO();
//            TransactionService transactionService = new TransactionService(transactionDAO);
//            transactionController = new TransactionController(transactionService);
//
//            // Create TextArea to show database content
//            TextArea textArea = new TextArea();
//            textArea.setEditable(false);
//            root.setCenter(textArea);
//
//            // Create Buttons for interaction
//            Button addTransactionButton = new Button("Add Transaction");
//            Button showTransactionsButton = new Button("Show Transactions");
//
//            // Create input fields for transaction details
//            TextField amountField = new TextField();
//            amountField.setPromptText("Amount");
//            TextField typeField = new TextField();
//            typeField.setPromptText("Income/Expense");
//            ComboBox<Category> categoryComboBox = new ComboBox<>();
//            categoryComboBox.getItems().addAll(fetchCategories());
//            TextField dateField = new TextField();
//            dateField.setPromptText("Transaction Date (dd-MM-yyyy)");
//            TextField descriptionField = new TextField(); // Description field added
//            descriptionField.setPromptText("Description");
//
//            // Button to add transaction
//            addTransactionButton.setOnAction(e -> {
//                try {
//                    double amount = Double.parseDouble(amountField.getText()); // Ensure it's a valid number
//                    String type = typeField.getText().trim();
//                    Category selectedCategory = categoryComboBox.getValue();
//                    String transactionDateString = dateField.getText().trim();
//                    String description = descriptionField.getText().trim();  // Get description from input field
//
//                    if (type.isEmpty() || selectedCategory == null || transactionDateString.isEmpty() || description.isEmpty()) {
//                        textArea.setText("Please fill in all fields correctly.");
//                        return;
//                    }
//
//                    // Validate the date format (dd-MM-yyyy)
//                    java.util.Date transactionDate = new SimpleDateFormat("dd-MM-yyyy").parse(transactionDateString);
//
//                    // Call the TransactionController to handle the add transaction logic
//                    if (transactionController.addTransaction(type, amount, description, transactionDateString, selectedCategory)) {
//                        textArea.setText("Transaction Added!");
//                    } else {
//                        textArea.setText("Failed to add transaction. Please check the input.");
//                    }
//                } catch (NumberFormatException ex) {
//                    textArea.setText("Invalid amount entered.");
//                } catch (ParseException ex) {
//                    textArea.setText("Invalid date format. Please use dd-MM-yyyy.");
//                }
//            });
//
//            // Button to show all transactions
//            showTransactionsButton.setOnAction(e -> {
//                textArea.setText(fetchTransactionsFromDatabase());
//            });
//
//            // Set up layout and add buttons
//            VBox vbox = new VBox(10, amountField, typeField, categoryComboBox, dateField, descriptionField, addTransactionButton, showTransactionsButton);
//            root.setLeft(vbox);
//
//            Scene scene = new Scene(root, 600, 600);
//            primaryStage.setTitle("Transaction Manager");
//            primaryStage.setScene(scene);
//            primaryStage.show();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    // Fetch all categories from the database to populate ComboBox
//    private List<Category> fetchCategories() {
//        List<Category> categories = new ArrayList<>();
//        String query = "SELECT category_id, name FROM categories"; // Assuming you have a categories table
//        try (Connection connection = DriverManager.getConnection(DB_URL);
//             Statement stmt = connection.createStatement();
//             ResultSet rs = stmt.executeQuery(query)) {
//            while (rs.next()) {
//                categories.add(new Category(rs.getInt("category_id"), rs.getString("name")));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return categories;
//    }
//
//    // Fetch transactions from the database to display
//    private String fetchTransactionsFromDatabase() {
//        StringBuilder transactionsData = new StringBuilder("\n=== Transactions ===\n");
//        transactionsData.append("Transaction ID\tCategory ID\tAmount\tDate\tDescription\n");
//        transactionsData.append("---------------------------------------------------------\n");
//
//        String query = "SELECT transaction_id, category_id, amount, transaction_date, description FROM transactions";
//        try (Connection connection = DriverManager.getConnection(DB_URL);
//             Statement stmt = connection.createStatement();
//             ResultSet resultSet = stmt.executeQuery(query)) {
//            while (resultSet.next()) {
//                transactionsData.append(resultSet.getInt("transaction_id")).append("\t")
//                        .append(resultSet.getInt("category_id")).append("\t")
//                        .append(resultSet.getDouble("amount")).append("\t")
//                        .append(resultSet.getDate("transaction_date")).append("\t")
//                        .append(resultSet.getString("description")).append("\n");
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            transactionsData.append("Error retrieving transactions: ").append(e.getMessage()).append("\n");
//        }
//        return transactionsData.toString();
//    }
//
//    public static void main(String[] args) {
//        launch(args);
//    }
//}




// u2 form with seperation but has conn error
//ok
//

//package application;
//
//import javafx.application.Application;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.DatePicker;
//import javafx.scene.control.TextArea;
//import javafx.stage.Stage;
//import controllers.ReportController;
//
//import java.util.Date;
//
//public class Main extends Application {
//
//private ReportController reportController;
//
//    @Override
//    public void start(Stage primaryStage) {
//        try {
//            // Load FXML from the views directory
//            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/u2.fxml"));
//            Parent root = loader.load();
//            System.out.println("FXML Loaded Successfully");
//
//            // Get the ReportController directly from FXMLLoader
//            reportController = loader.getController();
//
//            Scene scene = new Scene(root);
//            primaryStage.setScene(scene);
//            primaryStage.setTitle("Transaction Manager");
//            primaryStage.show();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//
//
//    public static void main(String[] args) {
//        launch(args);
//    }
//}




//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////


package application;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.ComboBox;
import java.util.HashMap;
import java.util.Map;

public class Main extends javafx.application.Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) {
        try {
            primaryStage = stage;
            switchScene("Home", "/views/Home2.fxml"); // Default to Home Page
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchScene(String title, String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource(fxmlPath));
            Parent root = loader.load();
            primaryStage.setTitle(title);
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}

// u3 form
//
//package application;
//
//import javafx.application.Application;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.TextArea;
//import javafx.scene.control.TextField;
//import javafx.stage.Stage;
//import controllers.BudgetController;
//
//public class Main extends Application {
//
//    @FXML
//    private Button setBudgetButton; // Ensure fx:id matches in FXML
//    @FXML
//    private TextField amountField;  // fx:id for amount input
//    @FXML
//    private TextField nameField;    // fx:id for name input
//    @FXML
//    private TextArea descriptionArea; // fx:id for description input
//
//    private BudgetController budgetController;
//
//    @Override
//    public void start(Stage primaryStage) {
//        try {
//            // Load FXML from the views directory
//            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/US3.fxml"));
//        //    FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/u2.fxml"));
//            Parent root = loader.load();
//            System.out.println("FXML Loaded Successfully");
//
//            // Get the BudgetController directly from FXMLLoader
//            budgetController = loader.getController();
//
//            Scene scene = new Scene(root);
//            primaryStage.setScene(scene);
//            primaryStage.setTitle("Set Budget");
//            primaryStage.show();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    /**
//     * Called when the "Set Budget" button is clicked.
//     */
//    
//
//    public static void main(String[] args) {
//        launch(args);
//    }
//}
//
