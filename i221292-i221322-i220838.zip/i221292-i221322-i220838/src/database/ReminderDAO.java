package database;

import models.Reminder;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReminderDAO {
    private Connection connection;

    public ReminderDAO(Connection connection) {
        this.connection = connection;
    }

    // Get reminders that are due today (SQL Server-specific)
    public List<Reminder> getRemindersDueToday() throws SQLException {
        List<Reminder> reminders = new ArrayList<>();
        String query = "SELECT * FROM reminders WHERE date = CAST(GETDATE() AS DATE)";  // Correct for SQL Server

        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Reminder reminder = new Reminder(rs.getDate("date"), rs.getString("description"));
                reminders.add(reminder);
            }
        }
        return reminders;
    }

    // Add a new reminder to the database
    public boolean addReminder(Reminder reminder) throws SQLException {
        String query = "INSERT INTO reminders (date, description) VALUES (?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setDate(1, reminder.getDate());
            pstmt.setString(2, reminder.getDescription());
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the reminder was successfully added
        }
    }
}
