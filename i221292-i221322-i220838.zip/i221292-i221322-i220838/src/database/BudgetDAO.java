package database;

import models.Budget;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class BudgetDAO {

    private Connection connection;

    public BudgetDAO(Connection connection) {
        this.connection = connection;
    }

    
    
    
    public boolean saveBudget(Budget bd) throws SQLException {
        String query = "INSERT INTO budget (amount, category, description, Sum, Alert) VALUES (?, ?, ?, ?, ?)";

        // Initialize the Sum and Alert values
        Double sum = 0.0;  // Assuming initial sum is 0. You can modify this logic if necessary.
        int alert = 0;     // Assuming alert is set to 0 initially (no alert).

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            // Set the parameters for the query
            pstmt.setDouble(1, bd.getAmount());  // Assuming you have a getAmount() method in Budget class
            pstmt.setString(2, bd.getCategory()); // Assuming you have a getCategory() method in Budget class
            pstmt.setString(3, bd.getDescription()); // Assuming you have a getDescription() method in Budget class
            pstmt.setDouble(4, sum);  // Setting the initial Sum (can be computed later)
            pstmt.setInt(5, alert);   // Setting the initial Alert value (no alert)

            // Execute the insert query
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0; // Return true if at least one row was inserted
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if there was an exception
        }
    }

    
 // Method to set the alert flag for a category
    public boolean setAlertForCategory(String name) throws SQLException {
        String query = "UPDATE budget SET alert = 1 WHERE category = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, name);  // Set the category ID for which alert needs to be set
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // If rows are updated, return true
        }
    }

    /**
     * Update the budget record in the database.
     */
    
    public List<String> getCategoriesFromBudget() throws SQLException {
        List<String> categories = new ArrayList<>();
        String query = "SELECT DISTINCT category FROM budget";  // SQL query to fetch distinct categories from the 'budget' table

        // Using try-with-resources to manage the PreparedStatement and the ResultSet
      //  try (
        		PreparedStatement pstmt = connection.prepareStatement(query);  // Prepare the statement using the existing connection
             ResultSet rs = pstmt.executeQuery(); 
             //) {  // Execute the query and get the result set

            // Loop through the result set and add each category to the list
            while (rs.next()) {
                categories.add(rs.getString("category"));  // Assuming "category" is the column name
            }
//        } catch (SQLException e) {
//            e.printStackTrace();  // Handle the exception (could be logged or rethrown depending on the use case)
//            throw e;  // Re-throwing the exception to let the calling method handle it
//        }
        
        return categories;  // Return the list of categories
    }
    
 // Check if the category exists in the budget table
    public boolean checkCategoryInBudget(String category) throws SQLException {
        String query = "SELECT COUNT(*) FROM budget WHERE category = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, category);
            ResultSet rs = pstmt.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;  // Returns true if the category exists
        }
    }

    // Check if the alert flag is set to 1 for a given category
    public boolean isAlertSetForCategory(String category) throws SQLException {
        String query = "SELECT alert FROM budget WHERE category = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, category);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("alert") == 1;
            }
            return false;
        }
    }

    // Get the current sum for the given category
    public double getCurrentSumForCategory(String category) throws SQLException {
        String query = "SELECT Sum FROM budget WHERE category = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, category);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("Sum");
            }
            return 0;
        }
    }

    // Get the target budget amount for the given category
    public double getBudgetAmountForCategory(String category) throws SQLException {
        String query = "SELECT amount FROM budget WHERE category = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, category);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("amount");
            }
            return 0;
        }
    }

    // Update the sum for the given category
    public boolean updateBudgetSum(String category, double newSum) throws SQLException {
        String query = "UPDATE budget SET Sum = ? WHERE category = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setDouble(1, newSum);
            pstmt.setString(2, category);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        }
    }
    
}
