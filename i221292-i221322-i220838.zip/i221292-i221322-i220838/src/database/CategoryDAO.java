package database;
import models.Category;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

public class CategoryDAO {
   public Category findCategoryById(int id) throws SQLException {
       String query = "SELECT * FROM categories WHERE id = ?";
    //   try (
    		   Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
       //     ) {
           pstmt.setInt(1, id);
           ResultSet rs = pstmt.executeQuery();
           if (rs.next()) {
               return new Category(rs.getInt("id"), rs.getString("name"));
           }
    //   } 
//       catch (SQLException e) {
//           e.printStackTrace();
//       }
       return null;
   }
   // Find category by name
   public Category findCategoryByName(String name) throws SQLException {
	    String query = "SELECT * FROM categories WHERE name = ?";
	    
	    // Get the connection and prepare statement without try-catch
	    Connection conn = DatabaseConnection.getConnection();
	    PreparedStatement pstmt = conn.prepareStatement(query);
	    pstmt.setString(1, name);
	    ResultSet rs = pstmt.executeQuery();
	    
	    if (rs.next()) {
	        return new Category(rs.getInt("category_id"), rs.getString("name"));
	    }
	    
	    return null; // Category not found
	}



// Save a new category to the database
   public boolean saveCategory(Category category) throws SQLException {
	    String query = "INSERT INTO categories (name) VALUES (?)";

	    Connection conn = DatabaseConnection.getConnection();
	    PreparedStatement pstmt = conn.prepareStatement(query);

	    pstmt.setString(1, category.getName());
	    int rowsAffected = pstmt.executeUpdate();

	    pstmt.close();
	   // conn.close();

	    return rowsAffected > 0; // Return true if the insert was successful
	}

   public boolean updateCategory(Category category) throws SQLException {
       String query = "UPDATE categories SET name = ? WHERE id = ?";
     //  try (
    		   Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            //) {
           pstmt.setString(1, category.getName());
           pstmt.setInt(2, category.getId());
           return pstmt.executeUpdate() > 0;
  //     } 
//   catch (SQLException e) {
//           e.printStackTrace();
//           return false;
//       }
   }
   
   // Method to get all categories from the database
   public List<Category> getAllCategories() throws SQLException {
       List<Category> categories = new ArrayList<>();
       String query = "SELECT * FROM categories";  // Assuming 'categories' is the table name in the DB
       
       //try (
    		   Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            		//) {

           // Execute the query and get the result set
           ResultSet rs = pstmt.executeQuery();

           // Iterate over the result set and map each row to a Category object
           while (rs.next()) {
               Category category = new Category(
                       rs.getInt("category_id"),  // Assuming category_id is the primary key
                       rs.getString("name")       // Assuming 'name' is the category name column
               );
               categories.add(category);  // Add each category to the list
          }
     //  }
       
       return categories;  // Return the list of categories
   }
}


