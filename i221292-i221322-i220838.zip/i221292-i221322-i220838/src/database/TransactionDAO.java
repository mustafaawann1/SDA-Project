package database;
import models.Transaction;


import models.Category;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


import java.util.Date;

public class TransactionDAO {

	

	  // Fetch transaction by ID
    public Transaction findTransactionById(int transactionId) throws SQLException {
        String query = "SELECT * FROM transactions WHERE transaction_id = ?";

        //try (
        		Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
            		// ) {
            pstmt.setInt(1, transactionId);  // Use int for transactionId
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // Create a Category object from the result (assuming category ID is retrieved and passed)
                Category category = new Category(rs.getInt("category_id"), "");  // Assuming category name is empty for now
                return new Transaction(
                        rs.getInt("transaction_id"),
                        rs.getDouble("amount"),
                        category,
                        rs.getDate("transaction_date"),
                        rs.getString("description")
                );
            }
       // }
//    catch (SQLException e) {
//            e.printStackTrace();
//        }
        return null;  // If transaction not found
    }

	public boolean saveTransaction(Transaction transaction) throws SQLException {
	    Connection conn = DatabaseConnection.getConnection();
	    if (conn == null) {
	        System.out.println("Failed to establish a connection to the database.");
	        return false;
	    }
	    
	    // Correct query with only 4 placeholders
	    String query = "INSERT INTO transactions (amount, category_id, transaction_date, description) VALUES (?, ?, ?, ?)";
	   // try (
	    		PreparedStatement pstmt = conn.prepareStatement(query);
	    	//	) {
	        pstmt.setDouble(1, transaction.getAmount());  // Set the amount
	        pstmt.setInt(2, transaction.getCategory().getId());  // Set category_id (category's ID)
	        pstmt.setDate(3, new java.sql.Date(transaction.getDate().getTime()));  // Set transaction_date
	        pstmt.setString(4, transaction.getDescription());  // Set description
	        
	        // Ensure that no extra parameters are being set
	        return pstmt.executeUpdate() > 0;  // Return true if transaction is added successfully
	  //  } 
//	catch (SQLException e) {
//	        e.printStackTrace();
//	        return false;
//	    }
	}




    public boolean updateTransaction(Transaction transaction) throws SQLException {
        String query = "UPDATE transactions SET amount = ?, transaction_date = ?, description = ?, category_id = ? WHERE transaction_id = ?";
     //   try (
        		Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
       //     		 ) {
            pstmt.setDouble(1, transaction.getAmount());
            pstmt.setDate(2, new java.sql.Date(transaction.getDate().getTime()));
            pstmt.setString(3, transaction.getDescription());
            pstmt.setInt(4, transaction.getCategory().getId());
            pstmt.setInt(5, transaction.getTransactionId());
            return pstmt.executeUpdate() > 0;
    //    } 
//    catch (SQLException e) {
//            e.printStackTrace();
//            return false;
//        }
    }

    public boolean deleteTransaction(int transactionId) throws SQLException {
        String query = "DELETE FROM transactions WHERE transaction_id = ?";
      //  try (
        		Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
         //   		 ) {
            pstmt.setInt(1, transactionId);
            return pstmt.executeUpdate() > 0;
     
    }
    

    public List<Transaction> getTransactionsByDateRange(Date startDate, Date endDate) throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT transaction_id, category_id, amount, transaction_date, description FROM transactions WHERE transaction_date BETWEEN ? AND ?";
        
      // try (
        		Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
          //  		 ) {
            
            stmt.setDate(1, new java.sql.Date(startDate.getTime()));
            stmt.setDate(2, new java.sql.Date(endDate.getTime()));

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Transaction transaction = new Transaction(
                    rs.getInt("transaction_id"),
                  //  rs.getString("type"),
                    rs.getDouble("amount"),
                    new Category(rs.getInt("category_id"), ""),
                    rs.getDate("transaction_date"),
                    rs.getString("description")
                );
                transactions.add(transaction);
            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        return transactions;
    }
    

    
 // Update the category_id in the transaction table
    public boolean updateTransactionCategory(int transactionId, int categoryId) throws SQLException {
        String query = "UPDATE transactions SET category_id = ? WHERE transaction_id = ?";
        
        Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(query);

        pstmt.setInt(1, categoryId);
        pstmt.setInt(2, transactionId);

        int rowsUpdated = pstmt.executeUpdate();
        pstmt.close();
      //  conn.close();

        return rowsUpdated > 0; // Return true if the transaction was updated successfully
    }

 // Method to get transactions by category ID
    public List<Transaction> getTransactionsByCategory(int categoryId) throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE category_id = ?";

     //   try (
        		Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             //) {

            pstmt.setInt(1, categoryId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Transaction transaction = new Transaction(
                        rs.getInt("transaction_id"),
                        rs.getDouble("amount"),
                        new Category(rs.getInt("category_id"), ""),
                        rs.getDate("transaction_date"),
                        rs.getString("description")
                );

                transactions.add(transaction);
            }
        //}

        return transactions;
    }
    public static double findSumOnCategory(Category c) throws SQLException
    {
    	double totalAmount = 0.0;
    	String query = "SELECT SUM(amount) AS total_amount FROM transactions WHERE category_id = ?";
    	Connection conn = DatabaseConnection.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(query);
    	
        pstmt.setInt(1, c.getId());  // Set the category ID to the query parameter
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) 
        {
            totalAmount = rs.getDouble("total_amount");  // Retrieve the sum from the result set
        }
        return totalAmount;
    }
    
 // Method to fetch all transactions from the database
    public List<Transaction> getAllTransactions() throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions";  // Adjust the query based on your table structure

        // Get the connection from DatabaseConnection
      //  try (
        		Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery();
 //           		 ) {

            // Iterate through the result set
            while (rs.next()) {
                // Create a new Transaction using the constructor that takes parameters
                Transaction transaction = new Transaction(
                    rs.getInt("transaction_id"),
                    rs.getDouble("amount"),
                    new Category(rs.getInt("category_id"), ""),  // Category constructor needs ID and name
                    rs.getDate("transaction_date"),
                    rs.getString("description")
                );

                // Add the transaction to the list
                transactions.add(transaction);
            }

//        } catch (SQLException e) {
//            e.printStackTrace();
//            throw e;  // Re-throw the exception after logging it
//        }

        return transactions;
    }
    
    
    //////////////////////////////////////////////////////////////////////////////////////////////////
    
 // Method to search transactions by Date
    public List<Transaction> searchTransactionsByDate(String date) throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE transaction_date LIKE ?";  // SQL query to match date

       // try (
        		Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
   //          ) {

            pstmt.setString(1, "%" + date + "%");
          //  try (
            		ResultSet rs = pstmt.executeQuery();
       //     		) {
                while (rs.next()) {
                    transactions.add(new Transaction(
                            rs.getInt("transaction_id"),
                            rs.getDouble("amount"),
                            new Category(rs.getInt("category_id"), ""),
                            rs.getDate("transaction_date"),
                            rs.getString("description")
                    ));
                }
         //   }
      //  }
        return transactions;
    }

    // Method to search transactions by Transaction ID
    public List<Transaction> searchTransactionsByTransactionId(String transactionId) throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE transaction_id = ?";

       // try (
        		Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
        //     ) {

            pstmt.setInt(1, Integer.parseInt(transactionId));  // Parsing ID to Integer
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    transactions.add(new Transaction(
                            rs.getInt("transaction_id"),
                            rs.getDouble("amount"),
                            new Category(rs.getInt("category_id"), ""),
                            rs.getDate("transaction_date"),
                            rs.getString("description")
                    ));
          //      }
            }
        }
        return transactions;
    }
    

    // Method to search transactions by Transaction ID
       public Transaction searchTransactionsByTransactionIdT(String transactionId) throws SQLException {
           Transaction transaction = null;  // Initialize a variable to hold a single transaction
           String query = "SELECT * FROM transactions WHERE transaction_id = ?";

           // Create connection and prepare the query
         //  try (
           		Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(query);
         //  		) {

               pstmt.setInt(1, Integer.parseInt(transactionId));  // Parsing ID to Integer

               // Execute the query
               try (ResultSet rs = pstmt.executeQuery()) {
                   // If there is a result, create a Transaction object
                   if (rs.next()) {
                       transaction = new Transaction(
                               rs.getInt("transaction_id"),
                               rs.getDouble("amount"),
                               new Category(rs.getInt("category_id"), ""),
                               rs.getDate("transaction_date"),
                               rs.getString("description")
                       );
                   }
               }
        //   }

           // Return the found transaction or null if not found
           return transaction;
       }

    // Method to search transactions by Description
    public List<Transaction> searchTransactionsByDescription(String description) throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE description LIKE ?";

      //  try (
        		Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
       //      ) {

            pstmt.setString(1, "%" + description + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    transactions.add(new Transaction(
                            rs.getInt("transaction_id"),
                            rs.getDouble("amount"),
                            new Category(rs.getInt("category_id"), ""),
                            rs.getDate("transaction_date"),
                            rs.getString("description")
                    ));
                }
            }
      //  }
        return transactions;
    }

}



