package database;

import models.Category;
import models.RecurringTransaction;
import models.Transaction;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RecurringTransactionDAO {

    private Connection connection;

    public RecurringTransactionDAO() {
        this.connection = DatabaseConnection.getConnection();
    }

    public boolean saveRecurringTransaction(RecurringTransaction recurringTransaction) throws SQLException {
        String query = "INSERT INTO transactions (amount, description, category_id, transaction_date) VALUES (?, ?, ?, ?)";
      //  try (
        		PreparedStatement pstmt = connection.prepareStatement(query);
      //  		) {
            pstmt.setDouble(1, recurringTransaction.getAmount());
            pstmt.setString(2, recurringTransaction.getDescription());
            pstmt.setInt(3, recurringTransaction.getCategory().getId());
            pstmt.setDate(4, new java.sql.Date(recurringTransaction.getTransactionDate().getTime()));

            int result = pstmt.executeUpdate();
            return result > 0;  // If the transaction was successfully inserted
      //  }
    }

    public List<Transaction> searchTransactionsByTransactionId(String transactionId) throws SQLException {
        String query = "SELECT * FROM transactions WHERE transaction_id = ?";
        List<Transaction> transactions = new ArrayList<>();
     //   try (
        		PreparedStatement pstmt = connection.prepareStatement(query);
    //    		) {
            pstmt.setString(1, transactionId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Transaction transaction = new Transaction(
                        rs.getInt("transaction_id"),
                        rs.getDouble("amount"),
                        new Category(rs.getInt("category_id"), ""),
                        rs.getDate("transaction_date"),
                        rs.getString("description")
                );
                transactions.add(transaction);
            }
     //   }
        return transactions;
    }
}
