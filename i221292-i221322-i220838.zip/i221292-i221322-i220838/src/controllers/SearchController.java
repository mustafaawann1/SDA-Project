package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import services.TransactionService;
import models.Transaction;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import application.Main;
import database.DatabaseConnection;
import database.TransactionDAO;

public class SearchController {

    @FXML
    private TextField transactionIDField;  // User input for search
    @FXML
    private ComboBox<String> categoryDropdown;  // Dropdown for search criteria
    @FXML
    private ListView<Transaction> searchResultsList;  // Display search results
    @FXML
    private Label feedbackLabel;  // Label to show feedback

    private TransactionService transactionService;

    public Main m; 
    @FXML
    public void goBackToHome() {
       
        	m.switchScene("Home", "/views/Home2.fxml");
           
    }

    public SearchController() {
    	Connection connection = DatabaseConnection.getConnection();
    	   TransactionDAO transactionDAO = new TransactionDAO();  // Create TransactionDAO
           transactionService = new TransactionService(transactionDAO, connection); 
    }

    @FXML
    public void initialize() {
        categoryDropdown.getItems().addAll("Date", "Transaction ID", "Description");  // Populate dropdown with fixed options
    }

    @FXML
    public void searchTransactions() throws SQLException {
        String searchCriteria = categoryDropdown.getValue();  // Get selected search criteria
        String input = transactionIDField.getText();  // Get user input

        if (searchCriteria == null || input.isEmpty()) {
            feedbackLabel.setText("Please select a search criterion and enter search data.");
            return;
        }

        List<Transaction> results = transactionService.searchTransactions(searchCriteria, input);

        if (results.isEmpty()) {
            feedbackLabel.setText("No results found.");
        } else {
            searchResultsList.getItems().setAll(results);
            feedbackLabel.setText(results.size() + " results found.");
        }
    }
}
