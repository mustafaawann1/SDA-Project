//package controllers;
//public class ExportController
//{
//	public Boolean exportCSV() {
//	    // Function logic here
//	    return false; // Placeholder return value
//	}
//
//	public Boolean confirmExport() {
//	    // Function logic here
//	    return false; // Placeholder return value
//	}
//
//	public Boolean download() {
//	    //  here parameter is File csvFile
//	    return false; // Placeholder return value
//	}
//	
//	#categorizeTransaction
//
//}


//package controllers;
//
//import javafx.fxml.FXML;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;
//import javafx.scene.control.ComboBox;
//import services.TransactionService;
//import services.CategoryService;
//import services.ExportService;
//import models.Category;
//import models.Transaction;
//import java.io.File;
//import java.sql.SQLException;
//import java.util.List;
//
//import database.TransactionDAO;
//
//public class ExportController {
//
//    @FXML
//    private ComboBox<Category> categoryComboBox;  // ComboBox to select the category
//    @FXML
//    private Button exportButton;  // Button to trigger the export
//    @FXML
//    private Label feedbackLabel;  // Feedback label to show status
//
//    private TransactionService transactionService;
//    private ExportService exportService;
//
//    // Constructor for dependency injection (TransactionService and ExportService)
//    public ExportController() {
//    	  // Initialize TransactionDAO and inject it into TransactionService
//        TransactionDAO transactionDAO = new TransactionDAO();  // Create TransactionDAO
//        transactionService = new TransactionService(transactionDAO);  // Inject TransactionDAO into TransactionService
//    	
//    	
//    	
//    	
//      //  this.transactionService = new TransactionService();
//        this.exportService = new ExportService();
//    }
// // Constructor used for explicit injection if needed (for advanced use cases)
//    public ExportController(TransactionService transactionService, ExportService exportService) {
//        this.transactionService = transactionService;
//        this.exportService = exportService;
//    }
//
//    // Method to handle export button click event
//    @FXML
//    public void exportCSV() throws SQLException {
//        // Get selected category
//        Category selectedCategory = categoryComboBox.getValue();
//        
//        if (selectedCategory != null) {
//            // Fetch transactions for the selected category
//            List<Transaction> transactions = transactionService.fetchTransactionsByCategory(selectedCategory.getId());
//            
//            if (transactions.isEmpty()) {
//                feedbackLabel.setText("No transactions found for this category.");
//            } else {
//                // Generate CSV file
//                File csvFile = exportService.generateCSV(transactions);
//                
//                // Notify the user
//                feedbackLabel.setText("CSV export successful! File saved at: " + csvFile.getAbsolutePath());
//            }
//        } else {
//            feedbackLabel.setText("Please select a category.");
//        }
//    }
//}


package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import services.ExportService;
import services.TransactionService;
import models.Transaction;
import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import utilities.AlertUtils;
import database.DatabaseConnection;
import database.TransactionDAO;
import application.Main;
public class ExportController {

    @FXML
    private Button exportButton;  // Button to trigger the export
    @FXML
    private Label feedbackLabel;  // Feedback label to show status
    public Main m; 
    @FXML
    private Button backButton;

    private TransactionService transactionService;
    private ExportService exportService;
    public AlertUtils popup;
    // Constructor for dependency injection (TransactionService and ExportService)
    
    
    public void goBackToHome() {
        
    	m.switchScene("Home", "/views/Home2.fxml");
       
}

    public ExportController() {
    	Connection connection = DatabaseConnection.getConnection();
    	TransactionDAO transactionDAO = new TransactionDAO();  // Create TransactionDAO
    	 this.transactionService = new TransactionService(transactionDAO, connection);  // Inject TransactionDAO into TransactionService
    	
    	
      //  this.transactionService = new TransactionService();
        this.exportService = new ExportService();
    }

    // Constructor used for explicit injection if needed (for advanced use cases)
    public ExportController(TransactionService transactionService, ExportService exportService) {
        this.transactionService = transactionService;
        this.exportService = exportService;
    }

    // Method to handle export button click event
    @FXML
    public void exportCSV() throws SQLException {
        // Fetch all transactions from the service (no category filter for now)
        List<Transaction> transactions = transactionService.fetchAllTransactions();

        if (transactions.isEmpty()) {
            feedbackLabel.setText("No transactions found.");
        } else {
            // Generate CSV file
            File csvFile = exportService.generateCSV(transactions);

            // Notify the user
            popup.showSuccess("CSV export successful!");
            feedbackLabel.setText("CSV export successful! File saved at: " + csvFile.getAbsolutePath());
        }
    }
}
