package controllers;

import application.Main;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class HomeController {

    @FXML private Button addTransactionButton;
    @FXML private Button viewHistoryButton;
    @FXML private Button editTransactionButton;
    @FXML private Button setBudgetButton;
    @FXML private Button generateReportButton;
    @FXML private Button categorizeTransactionButton;
    @FXML private Button exportToCsvButton;
    @FXML private Button receiveAlertsButton;
    @FXML private Button searchTransactionButton;
    @FXML private Button recurringTransactionButton;
    @FXML private Button futurePaymentsButton;
    																	// "/views/Home.fxml"
    @FXML
    private void initialize() {
        addTransactionButton.setOnAction(event -> Main.switchScene("addTransaction", "/views/US1-3.fxml"));
        viewHistoryButton.setOnAction(event -> Main.switchScene("transactionHistory", "/views/US2-3.fxml"));
        editTransactionButton.setOnAction(event -> Main.switchScene("editTransaction", "/views/US8-3.fxml"));
        setBudgetButton.setOnAction(event -> Main.switchScene("setBudget", "/views/US3.fxml"));
        generateReportButton.setOnAction(event -> Main.switchScene("generateReport", "/views/US4-3.fxml"));
        categorizeTransactionButton.setOnAction(event -> Main.switchScene("categorizeTransaction", "/views/US5-3.fxml"));
        exportToCsvButton.setOnAction(event -> Main.switchScene("exportCsv", "/views/US6-3.fxml"));
        receiveAlertsButton.setOnAction(event -> Main.switchScene("receiveAlerts", "/views/US7.fxml"));
        searchTransactionButton.setOnAction(event -> Main.switchScene("searchTransaction", "/views/US9-3.fxml"));
        recurringTransactionButton.setOnAction(event -> Main.switchScene("recurringTransaction", "/views/US10-3.fxml"));
        futurePaymentsButton.setOnAction(event -> Main.switchScene("futurePayments", "/views/us11.fxml"));
    }
}
