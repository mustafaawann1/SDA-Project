package config;
import java.util.Properties;
public class DatabaseConfig
{
	
}
